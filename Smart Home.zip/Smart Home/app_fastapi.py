from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Smart Home API")

class DeviceCommand(BaseModel):
    device: str
    action: str
    value: float | None = None

@app.get("/")
def read_root():
    return {"message": "Welcome to Smart Home API"}

@app.post("/api/device/control")
async def control_device(command: DeviceCommand):
    try:
        # Here you would implement the actual device control logic
        return {"status": "success", "device": command.device, "action": command.action}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
