import streamlit as st
import requests

def main():
    st.title("Smart Home Control")
    
    # Sidebar for device selection
    device = st.sidebar.selectbox("Select Device", ["Lights", "AC", "Fan", "Door"])
    action = st.sidebar.selectbox("Action", ["On", "Off", "Status"])
    
    if st.button("Execute Command"):
        # Here you would send the command to your IoT system
        st.success(f"Command sent to {device}: {action}")

if __name__ == "__main__":
    main()
